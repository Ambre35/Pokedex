<template>
    <div class="card">

        <div class="seb">
           <img :src="'assets/'+pokemon.image" alt="">
        <div class="btn">
            <button class=" eva">{{pokemon.name}}</button>
            
        </div>
        </div>

  

    </div>

</template>
<script>
export default {
    props: {
        pokemon: {
            type: Object,
            required: true
        }
    }
}
</script>
<style scoped>

.card{
    margin: 1em;
    padding:1em;
     border-radius: 15px;
     width: 18vw;
     display: flex;
     justify-content: center;
    }
    .seb{
        position: relative;
    }
.eva{
    font-family: "Poppins", sans-serif;
    font-weight: 700;
    font-size: 18px;
    background-color: transparent;
    border: none;
}

.btn{
    position: absolute;
    bottom: 2em;
    display: flex;
    justify-content: center;
    width: 100%;
}
</style>