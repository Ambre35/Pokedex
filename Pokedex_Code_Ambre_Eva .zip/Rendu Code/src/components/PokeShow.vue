<template>

<div>
  <img :src="'assets/cartepokemon/'+pokemon.carte" alt="">
</div>
  </template>

<script>

export default {
  name : "PokeShow",
  props : ['pokemon']
}

</script>

<style scoped>

</style>