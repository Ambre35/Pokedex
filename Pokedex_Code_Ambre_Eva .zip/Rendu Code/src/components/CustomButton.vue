<template>
    <input type="button" value='GO'>
</template><template>
    <PokeCard v-for="pokemon of pokemons" :key="pokemon" v-bind:pokemon="pokemon">
    </PokeCard>
</template>
<script>
import PokeCard from './PokeCard.vue'
import json_pokemons from '@/assets/pokemon.json'
export default {
  name: 'PokeList',
  components: {
    PokeCard
  },
  data() {
    return {
        pokemons: json_pokemons
    }
  },
  created(){

  }
}
</script>