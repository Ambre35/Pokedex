<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
    <h2 @click="change_name">{{ store.name }}</h2>
    <p>
      <ul>
        <li v-for="p of pokemons" :key="p">{{p.name}}</li>
      </ul>
    </p> 

  </div>
</template>

<script>
import { useCounterStore } from '@/store'
export default {
  name: 'HelloWorld',
  props: {
    msg: String
  },
  data () {
    return {
      pokemons: null,
      loaded: false,
      store: useCounterStore()
    }
  },
  methods: {
    async fetchPokemons(filename) {
      let data = await fetch(filename).then((res) => res.json())
      return data
    },
    change_name() {
      this.store.change_name('Merlin le druide')
    },
    async setData () {
            const data = await this.fetchPokemons("pokemon.json");
            this.loaded = true
            this.pokemons = data
        }
  },
    created() {
        this.setData()
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>