<template>
    <div class="container">
      <PokeShow :pokemon="selectedPokemon"/>
      <PokeCard v-for="pokemon of pokemons" :key="pokemon" v-bind:pokemon="pokemon" @click="selectedPokemon = pokemon"/>
    </div>
  </template>
  <script>
  import PokeCard from './PokeCard.vue'
  import PokeShow from './PokeShow.vue'

  import json_pokemons from '@/assets/pokemon.json'
  
  export default {
    name: 'PokeList',
    components: {
      PokeCard,
      PokeShow
    },
    data() {
      return {
          pokemons: json_pokemons,
          selectedPokemon: json_pokemons[0]
      }
    },
    methods: {
      mamethode() {
        console.log("On m'a clické dessus !!!")
      }
    },
    created(){
  
    }
  }
  </script>

  <style scoped>
  .container{
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
  }
  </style>