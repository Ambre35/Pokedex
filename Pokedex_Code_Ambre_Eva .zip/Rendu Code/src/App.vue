<template>
  <div>
    <header class="logo">
      <img src="./assets/International_Pokémon_logo.svg.png" alt="">
    </header>
    <main>
      <PokeList />
    </main>
  </div>
</template>

<script>
import PokeList from './components/PokeList.vue'

export default {
  name: 'App',
  components: {
    PokeList
  }
}
</script>

<style scoped>
header {
  display: flex;
  justify-content: space-around;
}

.logo{
  
  height : 150px;
  display: flex;
  justify-content: space-around ;
  margin: 50px;
}
</style>
